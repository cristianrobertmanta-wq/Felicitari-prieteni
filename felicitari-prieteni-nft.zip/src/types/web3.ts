export interface Friend {
  id: string;
  name: string;
  address: string;
  relationship: string;
  addedBy: string;
  timestamp: number;
  initialMember: boolean;
  avatarSeed: string;
}

export interface NFTGreeting {
  id: string;
  tokenId: number;
  toAddress: string;
  toName: string;
  fromAddress: string;
  fromName: string;
  title: string;
  message: string;
  ipfsUri: string;
  theme: 'gold' | 'winter' | 'starlight' | 'royal' | 'emerald';
  timestamp: number;
  txHash: string;
  blockNumber: number;
}

export interface NetworkConfig {
  chainIdHex: string;
  chainIdDec: number;
  name: string;
  rpcUrl: string;
  currencySymbol: string;
  blockExplorerUrl: string;
}

export const POLYGON_AMOY_CONFIG: NetworkConfig = {
  chainIdHex: '0x13882', // 80002
  chainIdDec: 80002,
  name: 'Polygon Amoy Testnet',
  rpcUrl: 'https://rpc-amoy.polygon.technology',
  currencySymbol: 'POL',
  blockExplorerUrl: 'https://amoy.polygonscan.com',
};
