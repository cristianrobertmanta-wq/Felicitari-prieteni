/**
 * Smart Contract Solidity pentru FelicitariPrieteni (ERC-721)
 * Compatibil cu rețeaua Polygon (Amoy Testnet)
 */

export const SOLIDITY_CONTRACT_SOURCE = `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC721/extensions/ERC721URIStorage.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

/**
 * @title FelicitariPrieteni
 * @dev Contract ERC-721 pentru emiterea de felicitari NFT permanente pe Polygon Amoy.
 * Permite membrilor grupului sa adauge noi persoane dragi si sa trimita felicitari NFT unice.
 */
contract FelicitariPrieteni is ERC721URIStorage, Ownable {
    uint256 private _tokenIds;

    struct PersoanaDraga {
        string nume;
        address adresaPortofel;
        address adaugatDe;
        uint256 timestamp;
    }

    struct DetaliiFelicitare {
        uint256 tokenId;
        address expeditor;
        address destinatar;
        string titlu;
        string mesaj;
        string uriImagine;
        uint256 dataTranzactie;
    }

    // Lista publica distribuita a persoanelor dragi inregistrate
    PersoanaDraga[] public persoaneDragi;

    // Mapare pentru a verifica daca o adresa este in grupul autorizat
    mapping(address => bool) public esteMembruGrup;
    
    // Mapare de la adresa la indexul din lista de persoane dragi
    mapping(address => bool) public esteInregistrat;

    // Mapare de la ID token la detaliile felicitarii
    mapping(uint256 => DetaliiFelicitare) public felicitari;

    // Mapare de la adresa destinatarului la lista ID-urilor de token primite
    mapping(address => uint256[]) private _felicitariPrimite;

    // Evenimente emise pe blockchain
    event PersoanaDragaAdaugata(string nume, address indexed adresaPortofel, address indexed adaugatDe, uint256 timestamp);
    event PersoanaDragaEliminata(address indexed adresaPortofel, address indexed eliminatDe, uint256 timestamp);
    event FelicitareEmisa(uint256 indexed tokenId, address indexed deLa, address indexed catre, string titlu, string uriImagine, uint256 timestamp);

    modifier doarMembruGrup() {
        require(esteMembruGrup[msg.sender], "Eroare: Doar membrii grupului autorizat pot efectua aceasta actiune!");
        _;
    }

    /**
     * @dev Constructorul initializeaza grupul
     * @param membriInitiali Lista adreselor de portofel ale membrilor initiali
     * @param numeInitiali Lista numelor corespunzatoare
     */
    constructor(address[] memory membriInitiali, string[] memory numeInitiali) 
        ERC721("Felicitari Prieteni Polygon", "FPRIETENI") 
        Ownable(msg.sender) 
    {
        // Creatorul devine automat membru al grupului
        esteMembruGrup[msg.sender] = true;

        for (uint256 i = 0; i < membriInitiali.length; i++) {
            address adresa = membriInitiali[i];
            if (adresa != address(0) && !esteMembruGrup[adresa]) {
                esteMembruGrup[adresa] = true;
                esteInregistrat[adresa] = true;
                persoaneDragi.push(PersoanaDraga({
                    nume: numeInitiali[i],
                    adresaPortofel: adresa,
                    adaugatDe: msg.sender,
                    timestamp: block.timestamp
                }));
            }
        }
    }

    /**
     * @notice Inregistreaza o noua persoana draga (sarbatorit) in registrul distribuit
     * @param nume Numele sau porecla persoanei dragi
     * @param adresaPortofel Adresa publica de portofel (0x...)
     */
    function adaugaPersoanaDraga(string memory nume, address adresaPortofel) public doarMembruGrup {
        require(adresaPortofel != address(0), "Adresa de portofel invalida!");
        require(!esteInregistrat[adresaPortofel], "Aceasta persoana este deja inregistrata!");
        require(bytes(nume).length > 0, "Numele nu poate fi gol!");

        esteMembruGrup[adresaPortofel] = true;
        esteInregistrat[adresaPortofel] = true;

        persoaneDragi.push(PersoanaDraga({
            nume: nume,
            adresaPortofel: adresaPortofel,
            adaugatDe: msg.sender,
            timestamp: block.timestamp
        }));

        emit PersoanaDragaAdaugata(nume, adresaPortofel, msg.sender, block.timestamp);
    }

    /**
     * @notice Elimina o persoana draga din lista publica si revoca permisiunea
     * @param adresaPortofel Adresa publica a persoanei eliminate
     */
    function eliminaPersoanaDraga(address adresaPortofel) public doarMembruGrup {
        require(esteInregistrat[adresaPortofel], "Aceasta persoana nu este inregistrata!");
        
        esteMembruGrup[adresaPortofel] = false;
        esteInregistrat[adresaPortofel] = false;

        for (uint256 i = 0; i < persoaneDragi.length; i++) {
            if (persoaneDragi[i].adresaPortofel == adresaPortofel) {
                persoaneDragi[i] = persoaneDragi[persoaneDragi.length - 1];
                persoaneDragi.pop();
                break;
            }
        }

        emit PersoanaDragaEliminata(adresaPortofel, msg.sender, block.timestamp);
    }

    /**
     * @notice Emite un NFT unic cu felicitarea de sarbatoare catre destinatar
     * @param catre Adresa publica a sarbatoritului
     * @param uriImagine Link-ul imaginii de pe IPFS/Pinata (ex: ipfs://Qm...)
     * @param titlu Ocazia sau titlul felicitarii (ex: La multi ani!)
     * @param mesaj Mesajul personalizat de felicitare
     * @return Noul ID unic de token generat
     */
    function mintFelicitare(
        address catre,
        string memory uriImagine,
        string memory titlu,
        string memory mesaj
    ) public doarMembruGrup returns (uint256) {
        require(catre != address(0), "Destinatarul nu poate fi adresa zero!");
        require(bytes(uriImagine).length > 0, "Link-ul imaginii IPFS este obligatoriu!");

        _tokenIds++;
        uint256 noulId = _tokenIds;

        _safeMint(catre, noulId);
        _setTokenURI(noulId, uriImagine);

        felicitari[noulId] = DetaliiFelicitare({
            tokenId: noulId,
            expeditor: msg.sender,
            destinatar: catre,
            titlu: titlu,
            mesaj: mesaj,
            uriImagine: uriImagine,
            dataTranzactie: block.timestamp
        });

        _felicitariPrimite[catre].push(noulId);

        emit FelicitareEmisa(noulId, msg.sender, catre, titlu, uriImagine, block.timestamp);

        return noulId;
    }

    /**
     * @notice Returneaza intreaga lista publica a persoanelor dragi inregistrate
     */
    function getToatePersoaneleDragi() external view returns (PersoanaDraga[] memory) {
        return persoaneDragi;
    }

    /**
     * @notice Returneaza toate ID-urile de felicitari primite de un sarbatorit
     */
    function getFelicitariPrimiteDe(address sarbatorit) external view returns (uint256[] memory) {
        return _felicitariPrimite[sarbatorit];
    }

    /**
     * @notice Numarul total de felicitari emise vreodata in contract
     */
    function totalFelicitari() external view returns (uint256) {
        return _tokenIds;
    }
}
`;

export const CONTRACT_ABI = [
  "constructor(address[] memory membriInitiali, string[] memory numeInitiali)",
  "event PersoanaDragaAdaugata(string nume, address indexed adresaPortofel, address indexed adaugatDe, uint256 timestamp)",
  "event PersoanaDragaEliminata(address indexed adresaPortofel, address indexed eliminatDe, uint256 timestamp)",
  "event FelicitareEmisa(uint256 indexed tokenId, address indexed deLa, address indexed catre, string titlu, string uriImagine, uint256 timestamp)",
  "function adaugaPersoanaDraga(string memory nume, address adresaPortofel) public",
  "function eliminaPersoanaDraga(address adresaPortofel) public",
  "function mintFelicitare(address catre, string memory uriImagine, string memory titlu, string memory mesaj) public returns (uint256)",
  "function getToatePersoaneleDragi() external view returns (tuple(string nume, address adresaPortofel, address adaugatDe, uint256 timestamp)[] memory)",
  "function getFelicitariPrimiteDe(address sarbatorit) external view returns (uint256[] memory)",
  "function felicitari(uint256 tokenId) external view returns (uint256 tokenId, address expeditor, address destinatar, string titlu, string mesaj, string uriImagine, uint256 dataTranzactie)",
  "function esteMembruGrup(address) external view returns (bool)",
  "function totalFelicitari() external view returns (uint256)",
  "function tokenURI(uint256 tokenId) external view returns (string memory)",
  "function ownerOf(uint256 tokenId) external view returns (address)"
];

// Adresa de contract implicită demonstrativă pentru Polygon Amoy
export const DEFAULT_CONTRACT_ADDRESS_AMOY = "0x78a635848e02F2489Bcf4a0A545300Bf0bB751f8";
