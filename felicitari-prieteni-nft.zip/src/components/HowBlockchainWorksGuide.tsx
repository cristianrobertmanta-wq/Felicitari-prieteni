import React, { useState } from 'react';
import { KeyRound, Users, Cloud, Sparkles, LayoutGrid, CheckCircle2, ExternalLink, Terminal, Coins, ArrowRight, Laptop } from 'lucide-react';
import { switchToPolygonAmoy } from '../services/web3Service';
import { POLYGON_AMOY_CONFIG } from '../types/web3';

export const HowBlockchainWorksGuide: React.FC = () => {
  const [activeStep, setActiveStep] = useState<number>(1);
  const [networkAdding, setNetworkAdding] = useState(false);
  const [networkSuccess, setNetworkSuccess] = useState(false);

  const handleAddNetwork = async () => {
    setNetworkAdding(true);
    try {
      await switchToPolygonAmoy();
      setNetworkSuccess(true);
      setTimeout(() => setNetworkSuccess(false), 4000);
    } catch (err) {
      console.error(err);
    } finally {
      setNetworkAdding(false);
    }
  };

  const STEPS = [
    {
      step: 1,
      title: 'Conectarea Portofelului (Autentificarea)',
      icon: KeyRound,
      color: 'from-amber-500 to-amber-700',
      summary: 'Portofelul trimite doar cheia ta publică (adresa 0x...). Nu ai nevoie de cont, parolă sau e-mail.',
      whatHappensOnChain: 'Nimic încă pe rețea. Portofelul tău partajează în mod securizat adresa publică cu aplicația web.',
      details: [
        'Aplicația cere permisiunea extensiei de browser (MetaMask, Phantom, etc.).',
        'Cheia privată rămâne 100% securizată în dispozitivul tău și nu este trimisă niciodată către server.',
        'Adresa ta (0x...) devine identitatea ta suverană, valabilă pe toate aplicațiile Web3.',
      ],
    },
    {
      step: 2,
      title: 'Adăugarea unei Persoane Dragi în Grup',
      icon: Users,
      color: 'from-blue-500 to-indigo-700',
      summary: 'Scrierea autorizației în registrul public distribuit al contractului inteligent.',
      whatHappensOnChain: 'MetaMask cere o semnătură digitală aprobată prin cheia privată. Tranzacția este confirmată de validatori și înscrisă în bloc.',
      details: [
        'Aplicația apelează funcția adaugaPersoanaDraga(nume, adresa) din contract.',
        'Calculatoarele din întreaga rețea Polygon execută codul și memorează asocierea.',
        'Din acest moment, adresa adăugată poate fi sărbătorită și poate trimite la rândul ei felicitări celorlalți.',
      ],
    },
    {
      step: 3,
      title: 'Pregătirea Felicitării (Design-ul și IPFS)',
      icon: Cloud,
      color: 'from-sky-500 to-cyan-700',
      summary: 'Stocarea descentralizată a imaginii pentru a evita costurile mari de gaz pe blockchain.',
      whatHappensOnChain: 'Nimic direct pe blockchain. Imaginea primește un hash criptografic unic de conținut (CID: ipfs://Qm...).',
      details: [
        'Deoarece salvarea de fișiere mari (imagini, audio, video) direct în contract este extrem de scumpă, se utilizează IPFS (InterPlanetary File System).',
        'Fiecare fișier primește o adresă bazată pe conținut (hash), garantând că imaginea nu poate fi modificată ulterior fără a schimba adresa.',
        'Blockchain-ul va stoca doar acest text scurt, asigurând costuri infime de tranzacționare.',
      ],
    },
    {
      step: 4,
      title: 'Trimiterea Felicitării (Emiterea NFT-ului)',
      icon: Sparkles,
      color: 'from-purple-500 to-fuchsia-700',
      summary: 'Execuția funcției mintFelicitare pe Polygon Amoy și sigilarea criptografică.',
      whatHappensOnChain: 'Nodurile creează un bloc nou: „Se emite NFT-ul #45. Proprietar: Sărbătorit. Link: ipfs://Qm...”. Sigilat prin Hash.',
      details: [
        'Smart contractul verifică automat dacă adresa ta este în lista de membri autorizați.',
        'Dacă verificarea trece, se emite un nou token standard ERC-721 cu proprietar adresa sărbătoritului.',
        'Tranzacția primește un Hash unic, este inclusă într-un bloc și legată criptografic de trecut pentru totdeauna.',
      ],
    },
    {
      step: 5,
      title: 'Afișarea pe „Peretele Amintirilor”',
      icon: LayoutGrid,
      color: 'from-emerald-500 to-teal-700',
      summary: 'Interogarea gratuită a nodurilor și construirea galeriei permanente.',
      whatHappensOnChain: 'Interogare read-only (view): nodurile returnează toate ID-urile de token-uri deținute de adresă.',
      details: [
        'Când sărbătoritul intră în aplicație, se trimite o cerere gratuită către nodul RPC Polygon: „Dă-mi toate NFT-urile lui 0x...”.',
        'Aplicația descarcă metadatele de pe IPFS și le afișează frumos ca pe o felicitare de colecție.',
        'Nimeni nu poate șterge felicitarea, nici măcar creatorul aplicației, garantând o amintire digitală pe viață.',
      ],
    },
  ];

  return (
    <div className="space-y-10 animate-in fade-in duration-300">
      {/* Intro Header */}
      <div className="border-b border-slate-800 pb-5">
        <h2 className="text-2xl font-bold text-white tracking-tight">
          🚶‍♂️ Fiecare pas explicat tehnic: Cum funcționează blockchain-ul?
        </h2>
        <p className="mt-1 text-sm text-slate-400">
          Ghidul complet pas cu pas pentru înțelegerea mecanismelor Web3, Polygon Amoy Testnet, IPFS și contractelor inteligente ERC-721.
        </p>
      </div>

      {/* 5 Steps Interactive Visual Flow */}
      <div className="space-y-6">
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 p-1.5 bg-slate-900 border border-slate-800 rounded-2xl">
          {STEPS.map((s) => {
            const Icon = s.icon;
            const isCurrent = activeStep === s.step;
            return (
              <button
                key={s.step}
                type="button"
                onClick={() => setActiveStep(s.step)}
                className={`p-3 rounded-xl text-left transition-all flex flex-col justify-between ${
                  isCurrent
                    ? 'bg-amber-500/15 border border-amber-400/60 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-[11px] font-mono font-bold ${isCurrent ? 'text-amber-400' : 'text-slate-500'}`}>
                    0{s.step}.
                  </span>
                  <Icon className={`w-4 h-4 ${isCurrent ? 'text-amber-400' : 'text-slate-500'}`} />
                </div>
                <span className="text-xs font-semibold leading-tight line-clamp-2">
                  {s.title.split('(')[0]}
                </span>
              </button>
            );
          })}
        </div>

        {/* Selected Step Expanded Card */}
        {(() => {
          const current = STEPS[activeStep - 1];
          const Icon = current.icon;
          return (
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 sm:p-8 space-y-6 shadow-xl">
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-tr ${current.color} flex items-center justify-center text-white shrink-0 shadow-lg`}>
                  <Icon className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-xs font-mono text-amber-400 font-bold uppercase tracking-wider">
                    Pasul {current.step} din 5
                  </span>
                  <h3 className="text-xl font-bold text-white tracking-tight mt-0.5">
                    {current.title}
                  </h3>
                  <p className="text-sm text-slate-300 mt-1 leading-relaxed">
                    {current.summary}
                  </p>
                </div>
              </div>

              {/* On-Chain Deep Dive */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5" />
                  Ce se întâmplă exact în rețeaua Blockchain:
                </span>
                <p className="text-sm text-slate-200 font-mono leading-relaxed bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                  {current.whatHappensOnChain}
                </p>
              </div>

              {/* Details Bullet points */}
              <div className="space-y-2">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Mecanismul explicat pe înțelesul tuturor:
                </h4>
                <div className="space-y-2">
                  {current.details.map((detail, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-300">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span className="leading-relaxed">{detail}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-between items-center pt-4 border-t border-slate-800">
                <button
                  type="button"
                  disabled={activeStep === 1}
                  onClick={() => setActiveStep(activeStep - 1)}
                  className="px-3.5 py-1.5 text-xs rounded-lg border border-slate-700 text-slate-300 disabled:opacity-30 hover:bg-slate-800"
                >
                  Pasul anterior
                </button>
                <button
                  type="button"
                  disabled={activeStep === 5}
                  onClick={() => setActiveStep(activeStep + 1)}
                  className="px-4 py-1.5 text-xs font-semibold rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 disabled:opacity-30 inline-flex items-center gap-1.5"
                >
                  <span>Următorul pas</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })()}
      </div>

      {/* Logistic Section 1: Polygon Amoy Testnet & Faucet */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
          <div className="flex items-center gap-2">
            <Coins className="w-5 h-5 text-amber-400" />
            <h3 className="text-base font-bold text-white">
              Cum obțineți fonduri de test gratuite (Faucet)?
            </h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Rețeaua Polygon Amoy Testnet utilizează monede de test numite <strong>POL</strong> (fostul MATIC). Aceste fonduri sunt 100% gratuite și sunt destinate testării aplicațiilor, fără a cheltui niciun ban real.
          </p>

          <div className="space-y-2.5 text-xs">
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
              <span className="font-semibold text-white block">1. Faucet Oficial Polygon:</span>
              <p className="text-slate-400">Introduceți adresa voastră și primiți 0.5 POL gratuit la fiecare 24 de ore.</p>
              <a
                href="https://faucet.polygon.technology/"
                target="_blank"
                rel="noreferrer"
                className="text-amber-400 hover:text-amber-300 inline-flex items-center gap-1 font-medium mt-1"
              >
                <span>Accesează faucet.polygon.technology</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
              <span className="font-semibold text-white block">2. Alchemy Polygon Amoy Faucet:</span>
              <p className="text-slate-400">Alternativă rapidă pentru obținerea fondurilor de test.</p>
              <a
                href="https://www.alchemy.com/faucets/polygon-amoy"
                target="_blank"
                rel="noreferrer"
                className="text-amber-400 hover:text-amber-300 inline-flex items-center gap-1 font-medium mt-1"
              >
                <span>Accesează Alchemy Amoy Faucet</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>

          <div className="pt-2">
            <button
              type="button"
              onClick={handleAddNetwork}
              disabled={networkAdding}
              className="w-full py-2.5 px-4 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors flex items-center justify-center gap-2"
            >
              {networkSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span className="text-emerald-400">Polygon Amoy a fost adăugat!</span>
                </>
              ) : (
                <>
                  <Coins className="w-4 h-4 text-amber-400" />
                  <span>Adaugă Rețeaua Polygon Amoy în MetaMask (1-Click)</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Logistic Section 2: Local Tools & Development Setup */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
          <div className="flex items-center gap-2">
            <Laptop className="w-5 h-5 text-indigo-400" />
            <h3 className="text-base font-bold text-white">
              Cum rulați acest proiect pe calculatorul propriu?
            </h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Pentru a rula și extinde această aplicație în regim propriu, aveți nevoie doar de câteva unelte gratuite:
          </p>

          <div className="space-y-2 text-xs">
            <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-start gap-2.5">
              <span className="font-mono text-amber-400 font-bold">1.</span>
              <div>
                <strong className="text-white">Node.js (versiunea 20+ LTS):</strong>
                <p className="text-slate-400 text-[11px]">Descărcați gratuit de pe nodejs.org pentru a rula pachetele JavaScript.</p>
              </div>
            </div>

            <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-start gap-2.5">
              <span className="font-mono text-amber-400 font-bold">2.</span>
              <div>
                <strong className="text-white">Visual Studio Code:</strong>
                <p className="text-slate-400 text-[11px]">Editor de cod gratuit (code.visualstudio.com) cu extensia Solidity.</p>
              </div>
            </div>

            <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-start gap-2.5">
              <span className="font-mono text-amber-400 font-bold">3.</span>
              <div>
                <strong className="text-white">Comenzi de rulare în terminal:</strong>
                <div className="mt-1 bg-slate-900 p-2 rounded text-[11px] font-mono text-amber-300 border border-slate-800">
                  npm install<br />
                  npm run dev
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
