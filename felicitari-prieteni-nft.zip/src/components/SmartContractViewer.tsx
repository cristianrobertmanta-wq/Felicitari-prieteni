import React, { useState } from 'react';
import { Code2, Copy, Check, ExternalLink, Terminal, Shield, CheckCircle2 } from 'lucide-react';
import { SOLIDITY_CONTRACT_SOURCE, CONTRACT_ABI } from '../contracts/FelicitariPrieteni';
import { getContractAddress, setContractAddress } from '../services/web3Service';

export const SmartContractViewer: React.FC = () => {
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedAbi, setCopiedAbi] = useState(false);
  const [currentAddress, setCurrentAddress] = useState(getContractAddress());
  const [isSaved, setIsSaved] = useState(false);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(SOLIDITY_CONTRACT_SOURCE);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCopyAbi = () => {
    navigator.clipboard.writeText(JSON.stringify(CONTRACT_ABI, null, 2));
    setCopiedAbi(true);
    setTimeout(() => setCopiedAbi(false), 2000);
  };

  const handleSaveAddress = (e: React.FormEvent) => {
    e.preventDefault();
    setContractAddress(currentAddress.trim());
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div className="border-b border-slate-800 pb-5">
        <h2 className="text-2xl font-bold text-white tracking-tight">
          Smart Contract Solidity: FelicitariPrieteni.sol
        </h2>
        <p className="mt-1 text-sm text-slate-400">
          Codul complet al contractului inteligent ERC-721 configurat pentru Polygon Amoy Testnet, cu control de acces pentru grupul de 20 de prieteni și registru distribuit pentru sărbătoriți.
        </p>
      </div>

      {/* Contract Address Configuration */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-white">Adresă Smart Contract Activă</h3>
          </div>
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 px-2.5 py-0.5 rounded border border-emerald-500/30">
            Polygon Amoy (80002)
          </span>
        </div>

        <form onSubmit={handleSaveAddress} className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={currentAddress}
            onChange={(e) => setCurrentAddress(e.target.value)}
            placeholder="0x..."
            className="flex-1 px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
          <button
            type="submit"
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg transition-colors shrink-0"
          >
            {isSaved ? 'Adresă Salvată!' : 'Actualizează Adresa'}
          </button>
        </form>
        <p className="text-[11px] text-slate-400">
          Dacă publicați contractul pe cont propriu folosind Remix, introduceți adresa generată aici pentru a conecta direct aplicația.
        </p>
      </div>

      {/* Remix Deployment Guide */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex items-center gap-2">
          <Terminal className="w-5 h-5 text-indigo-400" />
          <h3 className="text-base font-bold text-white">
            Cum publici contractul în 3 minute cu Remix IDE (Gratuit)
          </h3>
        </div>

        <ol className="list-decimal list-inside space-y-2 text-xs text-slate-300 leading-relaxed">
          <li>
            Deschideți <a href="https://remix.ethereum.org" target="_blank" rel="noreferrer" className="text-amber-400 underline font-medium">Remix Ethereum IDE</a> în browser.
          </li>
          <li>
            Creați un fișier nou numit <code>FelicitariPrieteni.sol</code> în folderul <code>contracts/</code> și lipiți codul de mai jos.
          </li>
          <li>
            În tab-ul <strong>Solidity Compiler</strong>, selectați versiunea <code>0.8.20</code> și apăsați <strong>Compile</strong>.
          </li>
          <li>
            În tab-ul <strong>Deploy & Run Transactions</strong>, la <em>Environment</em> alegeți <strong>Injected Provider - MetaMask</strong> (asigurați-vă că sunteți pe rețeaua Polygon Amoy cu fonduri din faucet).
          </li>
          <li>
            La Deploy, furnizați lista inițială de adrese și nume pentru cei 20 de prieteni și apăsați <strong>transact</strong>.
          </li>
        </ol>
      </div>

      {/* Solidity Code Block with Copy Actions */}
      <div className="rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden shadow-2xl">
        <div className="px-5 py-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Code2 className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-mono font-medium text-slate-200">
              contracts/FelicitariPrieteni.sol (Solidity ^0.8.20)
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyAbi}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            >
              {copiedAbi ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedAbi ? 'ABI Copiat' : 'Copiază ABI'}</span>
            </button>

            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-slate-950 transition-colors"
            >
              {copiedCode ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedCode ? 'Cod Copiat' : 'Copiază Codul Solidity'}</span>
            </button>
          </div>
        </div>

        <div className="p-4 sm:p-6 overflow-x-auto max-h-[500px]">
          <pre className="text-xs font-mono text-slate-300 leading-relaxed">
            {SOLIDITY_CONTRACT_SOURCE}
          </pre>
        </div>
      </div>
    </div>
  );
};
