import React, { useState } from 'react';
import { Sparkles, Filter, Search, Inbox, Send, Eye, ShieldCheck, Heart } from 'lucide-react';
import { NFTGreeting, Friend } from '../types/web3';
import { NFTCardVisualizer } from './NFTCardVisualizer';
import { shortenAddress } from '../services/web3Service';

interface Props {
  greetings: NFTGreeting[];
  activeAddress: string;
  activeName: string;
  onOpenGreeting: (greeting: NFTGreeting) => void;
  onGoToSendGreeting: () => void;
  friends: Friend[];
  onSelectActiveFriend: (friend: Friend) => void;
}

export const WallOfMemories: React.FC<Props> = ({
  greetings,
  activeAddress,
  activeName,
  onOpenGreeting,
  onGoToSendGreeting,
  friends,
  onSelectActiveFriend,
}) => {
  const [filterMode, setFilterMode] = useState<'received' | 'sent' | 'all'>('received');
  const [searchQuery, setSearchQuery] = useState('');

  // Filter greetings according to mode and search
  const filteredGreetings = greetings.filter((g) => {
    // Mode match
    const isReceived = g.toAddress.toLowerCase() === activeAddress.toLowerCase();
    const isSent = g.fromAddress.toLowerCase() === activeAddress.toLowerCase();

    if (filterMode === 'received' && !isReceived) return false;
    if (filterMode === 'sent' && !isSent) return false;

    // Search query match
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        g.title.toLowerCase().includes(q) ||
        g.message.toLowerCase().includes(q) ||
        g.toName.toLowerCase().includes(q) ||
        g.fromName.toLowerCase().includes(q) ||
        g.tokenId.toString().includes(q);
      if (!match) return false;
    }

    return true;
  });

  const receivedCount = greetings.filter(
    (g) => g.toAddress.toLowerCase() === activeAddress.toLowerCase()
  ).length;

  const sentCount = greetings.filter(
    (g) => g.fromAddress.toLowerCase() === activeAddress.toLowerCase()
  ).length;

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Hero / Header Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 border border-slate-800 p-6 sm:p-8">
        <div className="max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full text-xs font-medium bg-amber-500/10 text-amber-300 border border-amber-500/30">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Colecția Criptografică a Grupului pe Polygon Amoy</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Peretele Amintirilor Digitale
          </h1>

          <p className="text-sm text-slate-300 leading-relaxed">
            Fiecare felicitare este un NFT securizat pe blockchain-ul Polygon. Nimeni nu poate șterge sau altera aceste momente speciale, asigurând amintiri pe viață între cei 20 de prieteni și persoanele dragi adăugate.
          </p>

          {/* Quick Active Persona Switcher Ribbon */}
          <div className="pt-2 flex flex-wrap items-center gap-2 text-xs">
            <span className="text-slate-400">Vizualizezi ca:</span>
            <span className="font-semibold text-white px-2 py-0.5 rounded bg-slate-800 border border-slate-700">
              {activeName} ({shortenAddress(activeAddress)})
            </span>
            {friends.length > 0 && (
              <>
                <span className="text-slate-500">·</span>
                <span className="text-slate-400">Schimbă rapid utilizatorul:</span>
                <div className="flex flex-wrap items-center gap-1">
                  {friends.slice(0, 4).map((f) => (
                    <button
                      key={f.id}
                      onClick={() => onSelectActiveFriend(f)}
                      className={`px-2 py-0.5 rounded text-[11px] transition-colors ${
                        f.address.toLowerCase() === activeAddress.toLowerCase()
                          ? 'bg-amber-400 text-slate-950 font-bold'
                          : 'bg-slate-800/80 text-slate-300 hover:text-white hover:bg-slate-700'
                      }`}
                    >
                      {f.name.split(' ')[0]}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Interactive Filter Tabs (functional segmented control) */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-xl">
          <button
            onClick={() => setFilterMode('received')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 ${
              filterMode === 'received'
                ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <Inbox className="w-3.5 h-3.5" />
            <span>Primite de mine ({receivedCount})</span>
          </button>

          <button
            onClick={() => setFilterMode('sent')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 ${
              filterMode === 'sent'
                ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <Send className="w-3.5 h-3.5" />
            <span>Trimise de mine ({sentCount})</span>
          </button>

          <button
            onClick={() => setFilterMode('all')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 ${
              filterMode === 'all'
                ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Toate din grup ({greetings.length})</span>
          </button>
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Caută în felicitări..."
            className="w-full pl-9 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      {/* Grid of NFT Greetings */}
      {filteredGreetings.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredGreetings.map((greeting) => (
            <NFTCardVisualizer
              key={greeting.id}
              greeting={greeting}
              onOpenDetails={onOpenGreeting}
            />
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-12 text-center space-y-4">
          <div className="w-14 h-14 mx-auto rounded-full bg-slate-800 flex items-center justify-center text-slate-400">
            <Inbox className="w-7 h-7 text-amber-400" />
          </div>
          <div className="max-w-md mx-auto space-y-1">
            <h3 className="text-base font-semibold text-white">
              Nicio felicitare găsită
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              {filterMode === 'received'
                ? `Adresa ${shortenAddress(activeAddress)} nu a primit încă nicio felicitare NFT pe Polygon Amoy.`
                : filterMode === 'sent'
                ? 'Nu ai trimis încă nicio felicitare NFT din acest portofel.'
                : 'Nicio felicitare nu corespunde filtrelor tale de căutare.'}
            </p>
          </div>
          <div className="pt-2">
            <button
              onClick={onGoToSendGreeting}
              className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-all shadow-md inline-flex items-center gap-2"
            >
              <Send className="w-4 h-4" />
              <span>Trimite o Felicitare Acum</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
