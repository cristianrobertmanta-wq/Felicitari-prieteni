import React, { useState } from 'react';
import { Wallet, ChevronDown, Check, LogOut, ArrowRightLeft, Shield, ExternalLink } from 'lucide-react';
import { shortenAddress } from '../services/web3Service';
import { Friend, POLYGON_AMOY_CONFIG } from '../types/web3';

interface Props {
  activeTab: 'wall' | 'send' | 'friends' | 'guide' | 'contract';
  setActiveTab: (tab: 'wall' | 'send' | 'friends' | 'guide' | 'contract') => void;
  isConnected: boolean;
  activeAddress: string;
  activeName: string;
  balance: string;
  isSimulator: boolean;
  onConnectRealWallet: () => void;
  onToggleSimulatorAccount: (friend: Friend) => void;
  onDisconnect: () => void;
  friends: Friend[];
}

export const Header: React.FC<Props> = ({
  activeTab,
  setActiveTab,
  isConnected,
  activeAddress,
  activeName,
  balance,
  isSimulator,
  onConnectRealWallet,
  onToggleSimulatorAccount,
  onDisconnect,
  friends,
}) => {
  const [showWalletMenu, setShowWalletMenu] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full bg-slate-950/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single text element wordmark */}
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('wall');
            }}
            className="flex items-center gap-2 text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 hover:text-amber-400 transition-colors"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-purple-600 via-indigo-600 to-amber-500 flex items-center justify-center text-white shadow-sm font-black text-sm">
              FP
            </div>
            <span>Felicitari Prieteni</span>
          </a>

          {/* Zone 2: 4-5 clean single-line navigation links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
            <button
              onClick={() => setActiveTab('wall')}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'wall' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-0.5' : ''
              }`}
            >
              Peretele Amintirilor
            </button>
            <button
              onClick={() => setActiveTab('send')}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'send' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-0.5' : ''
              }`}
            >
              Trimite Felicitare
            </button>
            <button
              onClick={() => setActiveTab('friends')}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'friends' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-0.5' : ''
              }`}
            >
              Grupul de Prieteni
            </button>
            <button
              onClick={() => setActiveTab('guide')}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'guide' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-0.5' : ''
              }`}
            >
              Ghid Blockchain
            </button>
            <button
              onClick={() => setActiveTab('contract')}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'contract' ? 'text-amber-400 font-semibold border-b-2 border-amber-400 pb-0.5' : ''
              }`}
            >
              Smart Contract
            </button>
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="relative shrink-0 flex items-center gap-2">
            {!isConnected ? (
              <button
                type="button"
                onClick={onConnectRealWallet}
                className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-amber-400 to-amber-500 rounded-lg hover:from-amber-300 hover:to-amber-400 shadow-sm transition-all whitespace-nowrap shrink-0"
              >
                <Wallet className="w-4 h-4" />
                <span>Conectează Portofelul</span>
              </button>
            ) : (
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowWalletMenu(!showWalletMenu)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-900 hover:bg-slate-850 text-xs font-medium text-slate-200 transition-colors"
                >
                  <div className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span className="font-semibold text-white">{activeName || 'Portofel'}</span>
                  <span className="hidden sm:inline font-mono text-slate-400">
                    {shortenAddress(activeAddress)}
                  </span>
                  <span className="hidden md:inline font-mono text-amber-400 tabular-nums">
                    {balance} POL
                  </span>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {/* Dropdown wallet panel */}
                {showWalletMenu && (
                  <div
                    className="absolute right-0 mt-2 w-72 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl p-3 text-xs text-slate-200 z-50 animate-in fade-in slide-in-from-top-2 duration-150"
                    onMouseLeave={() => setShowWalletMenu(false)}
                  >
                    <div className="pb-3 border-b border-slate-800">
                      <div className="flex items-center justify-between text-slate-400 mb-1">
                        <span>Rețea Activă:</span>
                        <span className="text-emerald-400 font-medium">Polygon Amoy (80002)</span>
                      </div>
                      <div className="text-slate-400">
                        Sold Disponibil: <strong className="text-white font-mono">{balance} POL</strong>
                      </div>
                      <div className="text-[11px] font-mono text-slate-400 break-all mt-1">
                        {activeAddress}
                      </div>
                    </div>

                    {/* Quick Switch Persona for testing */}
                    {friends.length > 0 && (
                      <div className="py-2">
                        <span className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold block mb-1.5">
                          Comută Identitatea din Grup:
                        </span>
                        <div className="max-h-36 overflow-y-auto space-y-1 pr-1">
                          {friends.slice(0, 6).map((friend) => (
                            <button
                              key={friend.id}
                              type="button"
                              onClick={() => {
                                onToggleSimulatorAccount(friend);
                                setShowWalletMenu(false);
                              }}
                              className={`w-full flex items-center justify-between px-2 py-1.5 rounded text-left transition-colors ${
                                friend.address.toLowerCase() === activeAddress.toLowerCase()
                                  ? 'bg-amber-500/20 text-amber-300 font-semibold'
                                  : 'hover:bg-slate-800 text-slate-300'
                              }`}
                            >
                              <span className="truncate">{friend.name}</span>
                              <span className="text-[10px] font-mono text-slate-400">
                                {shortenAddress(friend.address)}
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                      <button
                        type="button"
                        onClick={onConnectRealWallet}
                        className="text-amber-400 hover:text-amber-300 flex items-center gap-1 text-[11px]"
                      >
                        <ArrowRightLeft className="w-3 h-3" />
                        <span>MetaMask Real</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          onDisconnect();
                          setShowWalletMenu(false);
                        }}
                        className="text-rose-400 hover:text-rose-300 flex items-center gap-1 text-[11px]"
                      >
                        <LogOut className="w-3 h-3" />
                        <span>Deconectează</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="md:hidden flex items-center justify-around py-2.5 border-t border-slate-800/60 text-xs font-medium text-slate-300 overflow-x-auto">
          <button
            onClick={() => setActiveTab('wall')}
            className={`whitespace-nowrap px-2 py-1 ${activeTab === 'wall' ? 'text-amber-400 font-semibold' : ''}`}
          >
            Amintiri
          </button>
          <button
            onClick={() => setActiveTab('send')}
            className={`whitespace-nowrap px-2 py-1 ${activeTab === 'send' ? 'text-amber-400 font-semibold' : ''}`}
          >
            Trimite NFT
          </button>
          <button
            onClick={() => setActiveTab('friends')}
            className={`whitespace-nowrap px-2 py-1 ${activeTab === 'friends' ? 'text-amber-400 font-semibold' : ''}`}
          >
            Prieteni
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`whitespace-nowrap px-2 py-1 ${activeTab === 'guide' ? 'text-amber-400 font-semibold' : ''}`}
          >
            Ghid
          </button>
          <button
            onClick={() => setActiveTab('contract')}
            className={`whitespace-nowrap px-2 py-1 ${activeTab === 'contract' ? 'text-amber-400 font-semibold' : ''}`}
          >
            Contract
          </button>
        </div>
      </div>
    </header>
  );
};
