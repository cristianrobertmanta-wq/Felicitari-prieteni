import React, { useState } from 'react';
import { Sparkles, ExternalLink, ShieldCheck, Copy, Check, Eye } from 'lucide-react';
import { NFTGreeting } from '../types/web3';
import { shortenAddress } from '../services/web3Service';

interface Props {
  greeting: NFTGreeting;
  onOpenDetails?: (greeting: NFTGreeting) => void;
  isCompact?: boolean;
}

export const THEME_STYLES: Record<string, {
  bgGradient: string;
  borderColor: string;
  accentText: string;
  badgeBg: string;
  ribbonColor: string;
  svgDecor: string;
}> = {
  gold: {
    bgGradient: 'from-amber-950/80 via-slate-900 to-amber-950/60',
    borderColor: 'border-amber-500/40 hover:border-amber-400',
    accentText: 'text-amber-400',
    badgeBg: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
    ribbonColor: 'from-amber-400 via-yellow-300 to-amber-500',
    svgDecor: 'gold',
  },
  winter: {
    bgGradient: 'from-sky-950/80 via-slate-900 to-indigo-950/60',
    borderColor: 'border-cyan-500/40 hover:border-cyan-400',
    accentText: 'text-cyan-300',
    badgeBg: 'bg-cyan-500/20 text-cyan-200 border-cyan-500/40',
    ribbonColor: 'from-cyan-300 via-sky-200 to-indigo-400',
    svgDecor: 'winter',
  },
  starlight: {
    bgGradient: 'from-purple-950/80 via-slate-900 to-violet-950/60',
    borderColor: 'border-violet-500/40 hover:border-violet-400',
    accentText: 'text-violet-300',
    badgeBg: 'bg-violet-500/20 text-violet-200 border-violet-500/40',
    ribbonColor: 'from-violet-400 via-fuchsia-300 to-purple-500',
    svgDecor: 'starlight',
  },
  royal: {
    bgGradient: 'from-rose-950/80 via-slate-900 to-pink-950/60',
    borderColor: 'border-rose-500/40 hover:border-rose-400',
    accentText: 'text-rose-300',
    badgeBg: 'bg-rose-500/20 text-rose-200 border-rose-500/40',
    ribbonColor: 'from-rose-400 via-pink-300 to-rose-500',
    svgDecor: 'royal',
  },
  emerald: {
    bgGradient: 'from-emerald-950/80 via-slate-900 to-teal-950/60',
    borderColor: 'border-emerald-500/40 hover:border-emerald-400',
    accentText: 'text-emerald-300',
    badgeBg: 'bg-emerald-500/20 text-emerald-200 border-emerald-500/40',
    ribbonColor: 'from-emerald-400 via-teal-300 to-emerald-500',
    svgDecor: 'emerald',
  },
};

export const FestiveVectorArt: React.FC<{ theme: string; title: string; tokenId?: number }> = ({ theme, title, tokenId }) => {
  return (
    <div className="relative w-full h-44 sm:h-48 overflow-hidden rounded-t-xl flex items-center justify-center select-none bg-slate-950">
      {/* Background patterned mesh */}
      <div className="absolute inset-0 opacity-40 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-500/30 via-slate-900/60 to-slate-950" />
      
      {/* Dynamic theme illustrations */}
      {theme === 'gold' && (
        <svg viewBox="0 0 400 240" className="w-full h-full object-cover">
          <defs>
            <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="50%" stopColor="#d97706" />
              <stop offset="100%" stopColor="#78350f" />
            </linearGradient>
            <radialGradient id="sunGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#fbbf24" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#b45309" stopOpacity="0" />
            </radialGradient>
          </defs>
          <circle cx="200" cy="120" r="90" fill="url(#sunGlow)" />
          <path d="M200 40 L212 95 L267 80 L228 120 L270 155 L215 148 L200 200 L185 148 L130 155 L172 120 L133 80 L188 95 Z" fill="url(#goldGrad)" opacity="0.9" />
          <circle cx="90" cy="60" r="18" fill="#fef3c7" opacity="0.4" />
          <circle cx="310" cy="160" r="14" fill="#fde68a" opacity="0.5" />
          <circle cx="120" cy="180" r="8" fill="#fbbf24" opacity="0.6" />
          <circle cx="290" cy="70" r="10" fill="#f59e0b" opacity="0.7" />
          <text x="200" y="215" textAnchor="middle" fill="#fef08a" fontSize="13" fontWeight="600" letterSpacing="3">POLYGON AMOY NFT</text>
        </svg>
      )}

      {theme === 'winter' && (
        <svg viewBox="0 0 400 240" className="w-full h-full object-cover">
          <defs>
            <linearGradient id="auroraGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#38bdf8" />
              <stop offset="50%" stopColor="#6366f1" />
              <stop offset="100%" stopColor="#0f172a" />
            </linearGradient>
          </defs>
          <rect width="400" height="240" fill="url(#auroraGrad)" opacity="0.7" />
          {/* Stylized geometric snowflake */}
          <g transform="translate(200, 110) scale(1.1)">
            {[0, 60, 120, 180, 240, 300].map((deg) => (
              <g key={deg} transform={`rotate(${deg})`}>
                <line x1="0" y1="0" x2="0" y2="-65" stroke="#e0f2fe" strokeWidth="3" strokeLinecap="round" />
                <line x1="0" y1="-30" x2="-16" y2="-45" stroke="#bae6fd" strokeWidth="2.5" strokeLinecap="round" />
                <line x1="0" y1="-30" x2="16" y2="-45" stroke="#bae6fd" strokeWidth="2.5" strokeLinecap="round" />
                <circle cx="0" cy="-65" r="4" fill="#ffffff" />
              </g>
            ))}
            <circle cx="0" cy="0" r="9" fill="#e0f2fe" />
          </g>
          <text x="200" y="215" textAnchor="middle" fill="#bae6fd" fontSize="13" fontWeight="600" letterSpacing="3">HOLIDAY EDITION</text>
        </svg>
      )}

      {theme === 'starlight' && (
        <svg viewBox="0 0 400 240" className="w-full h-full object-cover">
          <defs>
            <linearGradient id="cosmicGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#a855f7" />
              <stop offset="50%" stopColor="#4338ca" />
              <stop offset="100%" stopColor="#090514" />
            </linearGradient>
          </defs>
          <rect width="400" height="240" fill="url(#cosmicGrad)" opacity="0.75" />
          <path d="M 50 140 Q 150 60 200 120 T 350 90" fill="none" stroke="#e9d5ff" strokeWidth="2" strokeDasharray="4 6" opacity="0.6" />
          <circle cx="200" cy="110" r="35" fill="none" stroke="#f3e8ff" strokeWidth="2" opacity="0.4" />
          <circle cx="200" cy="110" r="5" fill="#fdf4ff" />
          <polygon points="200,65 208,100 245,110 208,120 200,155 192,120 155,110 192,100" fill="#f5d0fe" />
          <circle cx="100" cy="70" r="3" fill="#ffffff" />
          <circle cx="320" cy="60" r="4" fill="#ffffff" />
          <circle cx="290" cy="160" r="3" fill="#ffffff" />
          <text x="200" y="215" textAnchor="middle" fill="#f5d0fe" fontSize="13" fontWeight="600" letterSpacing="3">FRIENDSHIP CONSTELLATION</text>
        </svg>
      )}

      {theme === 'royal' && (
        <svg viewBox="0 0 400 240" className="w-full h-full object-cover">
          <defs>
            <linearGradient id="rubyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f43f5e" />
              <stop offset="50%" stopColor="#881337" />
              <stop offset="100%" stopColor="#1e050f" />
            </linearGradient>
          </defs>
          <rect width="400" height="240" fill="url(#rubyGrad)" opacity="0.75" />
          {/* Royal Crest / Crown */}
          <path d="M140 145 L150 90 L180 125 L200 70 L220 125 L250 90 L260 145 Z" fill="#fecdd3" stroke="#fda4af" strokeWidth="2" />
          <circle cx="150" cy="85" r="5" fill="#fff1f2" />
          <circle cx="200" cy="65" r="7" fill="#fff1f2" />
          <circle cx="250" cy="85" r="5" fill="#fff1f2" />
          <rect x="140" y="148" width="120" height="12" rx="3" fill="#fb7185" />
          <text x="200" y="215" textAnchor="middle" fill="#ffe4e6" fontSize="13" fontWeight="600" letterSpacing="3">CELEBRATION OF MERIT</text>
        </svg>
      )}

      {theme === 'emerald' && (
        <svg viewBox="0 0 400 240" className="w-full h-full object-cover">
          <defs>
            <linearGradient id="emeraldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#10b981" />
              <stop offset="50%" stopColor="#064e3b" />
              <stop offset="100%" stopColor="#022c22" />
            </linearGradient>
          </defs>
          <rect width="400" height="240" fill="url(#emeraldGrad)" opacity="0.75" />
          {/* Emerald geometric diamond cut */}
          <polygon points="160,80 240,80 270,120 200,175 130,120" fill="#a7f3d0" opacity="0.85" stroke="#34d399" strokeWidth="2" />
          <polygon points="160,80 240,80 220,120 180,120" fill="#6ee7b7" opacity="0.5" />
          <line x1="130" y1="120" x2="270" y2="120" stroke="#059669" strokeWidth="1.5" />
          <line x1="200" y1="175" x2="180" y2="120" stroke="#059669" strokeWidth="1.5" />
          <line x1="200" y1="175" x2="220" y2="120" stroke="#059669" strokeWidth="1.5" />
          <text x="200" y="215" textAnchor="middle" fill="#d1fae5" fontSize="13" fontWeight="600" letterSpacing="3">ETERNAL HARMONY</text>
        </svg>
      )}

      {/* Hologram Overlay Foil */}
      <div className="absolute inset-0 bg-gradient-to-tr from-white/5 via-transparent to-white/10 pointer-events-none" />

      {/* Title Watermark Header */}
      <div className="absolute bottom-2 left-3 right-3 flex items-center justify-between pointer-events-none">
        <span className="text-[11px] font-mono tracking-wider text-slate-300/80 uppercase">
          ERC-721 #{tokenId ? tokenId.toString().padStart(4, '0') : '0045'}
        </span>
        <span className="flex items-center gap-1 text-[11px] font-medium text-emerald-400 bg-slate-900/80 px-2 py-0.5 rounded border border-emerald-500/30">
          <ShieldCheck className="w-3 h-3" /> Polygon Verified
        </span>
      </div>
    </div>
  );
};

export const NFTCardVisualizer: React.FC<Props> = ({ greeting, onOpenDetails, isCompact = false }) => {
  const [copied, setCopied] = useState(false);
  const theme = THEME_STYLES[greeting.theme] || THEME_STYLES.gold;

  const handleCopyHash = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(greeting.txHash);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formattedDate = new Date(greeting.timestamp).toLocaleDateString('ro-RO', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  return (
    <div
      onClick={() => onOpenDetails && onOpenDetails(greeting)}
      className={`group relative rounded-xl border bg-gradient-to-b ${theme.bgGradient} ${theme.borderColor} transition-all duration-300 hover:shadow-xl hover:shadow-amber-500/5 hover:-translate-y-1 cursor-pointer overflow-hidden flex flex-col justify-between`}
    >
      <div>
        {/* Visual Artwork Area */}
        <FestiveVectorArt theme={greeting.theme} title={greeting.title} tokenId={greeting.tokenId} />

        {/* Card Content */}
        <div className="p-4 sm:p-5">
          {/* Header row: Recipient & Date */}
          <div className="flex items-baseline justify-between text-xs text-slate-400 mb-2">
            <span className="font-medium text-slate-300">
              Pentru: <strong className="text-white font-semibold">{greeting.toName}</strong>
            </span>
            <span className="font-mono text-[11px] tabular-nums">{formattedDate}</span>
          </div>

          {/* Title */}
          <h3 className="text-base sm:text-lg font-semibold text-white tracking-tight leading-snug mb-2 group-hover:text-amber-300 transition-colors line-clamp-1">
            {greeting.title}
          </h3>

          {/* Message snippet */}
          <p className="text-sm text-slate-300/90 leading-relaxed line-clamp-3 mb-4 italic font-serif">
            "{greeting.message}"
          </p>
        </div>
      </div>

      {/* Card Footer with Blockchain Proofs */}
      <div className="px-4 py-3 sm:px-5 bg-slate-950/70 border-t border-slate-800/80 flex items-center justify-between text-xs">
        <div className="flex items-center gap-1.5 text-slate-400">
          <span className="text-[11px]">De la:</span>
          <span className="text-white font-medium text-[11px] truncate max-w-[100px] sm:max-w-[120px]">
            {greeting.fromName}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleCopyHash}
            title={`Copiază Hash Tranzacție: ${greeting.txHash}`}
            className="flex items-center gap-1 text-[11px] font-mono text-slate-400 hover:text-amber-300 transition-colors"
          >
            {copied ? (
              <>
                <Check className="w-3 h-3 text-emerald-400" />
                <span className="text-emerald-400">Copiat</span>
              </>
            ) : (
              <>
                <Copy className="w-3 h-3" />
                <span>{shortenAddress(greeting.txHash)}</span>
              </>
            )}
          </button>

          <span
            className="p-1 rounded bg-slate-800/80 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
            title="Deschide Felicitarea Completă"
          >
            <Eye className="w-3.5 h-3.5" />
          </span>
        </div>
      </div>
    </div>
  );
};
