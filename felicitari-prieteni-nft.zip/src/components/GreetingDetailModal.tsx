import React, { useState } from 'react';
import { X, ExternalLink, ShieldCheck, Copy, Check, Sparkles, Share2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { NFTGreeting, POLYGON_AMOY_CONFIG } from '../types/web3';
import { shortenAddress } from '../services/web3Service';
import { FestiveVectorArt, THEME_STYLES } from './NFTCardVisualizer';

interface Props {
  greeting: NFTGreeting | null;
  onClose: () => void;
}

export const GreetingDetailModal: React.FC<Props> = ({ greeting, onClose }) => {
  const [copiedHash, setCopiedHash] = useState(false);
  const [copiedIPFS, setCopiedIPFS] = useState(false);

  if (!greeting) return null;

  const theme = THEME_STYLES[greeting.theme] || THEME_STYLES.gold;

  const triggerCelebration = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#fbbf24', '#f59e0b', '#38bdf8', '#c084fc', '#ffffff'],
    });
  };

  const copyToClipboard = (text: string, type: 'hash' | 'ipfs') => {
    navigator.clipboard.writeText(text);
    if (type === 'hash') {
      setCopiedHash(true);
      setTimeout(() => setCopiedHash(false), 2000);
    } else {
      setCopiedIPFS(true);
      setTimeout(() => setCopiedIPFS(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl bg-slate-900 border border-slate-700/80 shadow-2xl text-slate-100 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          aria-label="Închide"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header Art */}
        <div className="relative">
          <FestiveVectorArt theme={greeting.theme} title={greeting.title} tokenId={greeting.tokenId} />
          
          <button
            onClick={triggerCelebration}
            className="absolute top-4 left-4 z-10 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-slate-900/90 text-amber-300 border border-amber-500/40 shadow-lg hover:scale-105 transition-transform"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Sărbătorește</span>
          </button>
        </div>

        {/* Body content */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Main Title & Occasion */}
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
              <span>Felicitare NFT ERC-721</span>
              <span>·</span>
              <span className="font-mono text-amber-400">Token ID #{greeting.tokenId}</span>
              <span>·</span>
              <span>Polygon Amoy Testnet</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              {greeting.title}
            </h2>
          </div>

          {/* Caligraphic Message Container */}
          <div className="p-6 rounded-xl bg-slate-950/60 border border-slate-800 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-bl-full pointer-events-none" />
            <p className="text-base sm:text-lg text-slate-200 font-serif italic leading-relaxed whitespace-pre-line">
              "{greeting.message}"
            </p>
            <div className="mt-4 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
              <span>
                Semnat cu drag de: <strong className="text-white">{greeting.fromName}</strong>
              </span>
              <span>
                Destinat lui: <strong className="text-white">{greeting.toName}</strong>
              </span>
            </div>
          </div>

          {/* Blockchain Provenance Data */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Registru Public Criptografic (Polygon Amoy)
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              {/* Recipient */}
              <div className="p-3 rounded-lg bg-slate-950/40 border border-slate-800">
                <span className="text-slate-400 block mb-0.5">Sărbătorit (Destinatar):</span>
                <span className="font-mono text-slate-200 break-all">{greeting.toAddress}</span>
              </div>

              {/* Sender */}
              <div className="p-3 rounded-lg bg-slate-950/40 border border-slate-800">
                <span className="text-slate-400 block mb-0.5">Expeditor (Membru autorizat):</span>
                <span className="font-mono text-slate-200 break-all">{greeting.fromAddress}</span>
              </div>

              {/* Transaction Hash */}
              <div className="p-3 rounded-lg bg-slate-950/40 border border-slate-800">
                <div className="flex items-center justify-between mb-0.5">
                  <span className="text-slate-400">Hash Tranzacție:</span>
                  <button
                    onClick={() => copyToClipboard(greeting.txHash, 'hash')}
                    className="text-amber-400 hover:text-amber-300 flex items-center gap-1"
                  >
                    {copiedHash ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedHash ? 'Copiat' : 'Copiază'}</span>
                  </button>
                </div>
                <span className="font-mono text-slate-300 break-all">{greeting.txHash}</span>
              </div>

              {/* IPFS URI */}
              <div className="p-3 rounded-lg bg-slate-950/40 border border-slate-800">
                <div className="flex items-center justify-between mb-0.5">
                  <span className="text-slate-400">Metadate IPFS (Pinata):</span>
                  <button
                    onClick={() => copyToClipboard(greeting.ipfsUri, 'ipfs')}
                    className="text-amber-400 hover:text-amber-300 flex items-center gap-1"
                  >
                    {copiedIPFS ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedIPFS ? 'Copiat' : 'Copiază'}</span>
                  </button>
                </div>
                <span className="font-mono text-slate-300 break-all">{greeting.ipfsUri}</span>
              </div>
            </div>
          </div>

          {/* Action Row */}
          <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-slate-800">
            <a
              href={`${POLYGON_AMOY_CONFIG.blockExplorerUrl}/tx/${greeting.txHash}`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 transition-colors"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Verifică pe Polygonscan Amoy</span>
            </a>

            <button
              onClick={onClose}
              className="px-5 py-2 rounded-lg text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-slate-950 transition-colors"
            >
              Închide
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
