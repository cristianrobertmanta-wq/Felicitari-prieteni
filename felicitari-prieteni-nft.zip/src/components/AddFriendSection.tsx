import React, { useState } from 'react';
import { UserPlus, Search, ShieldCheck, ExternalLink, Send, CheckCircle2, AlertCircle, Trash2 } from 'lucide-react';
import { Friend, POLYGON_AMOY_CONFIG } from '../types/web3';
import { shortenAddress, generatePseudoTxHash } from '../services/web3Service';

interface Props {
  friends: Friend[];
  onAddFriend: (newFriend: Friend) => void;
  onDeleteFriend: (friendId: string) => void;
  onClearAllFriends: () => void;
  onSelectRecipientForGreeting: (friend: Friend) => void;
  activeAddress: string;
  activeName: string;
}

export const AddFriendSection: React.FC<Props> = ({
  friends,
  onAddFriend,
  onDeleteFriend,
  onClearAllFriends,
  onSelectRecipientForGreeting,
  activeAddress,
  activeName,
}) => {
  const [friendToDelete, setFriendToDelete] = useState<Friend | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [relationship, setRelationship] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Validate Ethereum/Polygon address format
  const isValidAddress = (addr: string) => /^0x[a-fA-F0-9]{40}$/.test(addr.trim());

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    const cleanName = name.trim();
    const cleanAddr = address.trim();
    const cleanRel = relationship.trim() || 'Persoană Dragă';

    if (!cleanName) {
      setErrorMessage('Te rugăm să introduci numele persoanei dragi.');
      return;
    }

    if (!isValidAddress(cleanAddr)) {
      setErrorMessage('Adresa de portofel trebuie să fie o adresă validă Ethereum/Polygon (începe cu 0x urmat de 40 de caractere hexadecimale).');
      return;
    }

    // Check if already in list
    const alreadyExists = friends.some(
      (f) => f.address.toLowerCase() === cleanAddr.toLowerCase()
    );
    if (alreadyExists) {
      setErrorMessage('Această adresă de portofel este deja înregistrată în grupul comun!');
      return;
    }

    setIsSubmitting(true);

    // Simulate blockchain confirmation & storage
    setTimeout(() => {
      const newFriend: Friend = {
        id: `friend-${Date.now()}`,
        name: cleanName,
        address: cleanAddr,
        relationship: cleanRel,
        addedBy: activeAddress,
        timestamp: Date.now(),
        initialMember: false,
        avatarSeed: cleanName.toLowerCase().replace(/\s+/g, '-'),
      };

      onAddFriend(newFriend);
      setIsSubmitting(false);
      setSuccessMessage(`Persoana „${cleanName}” a fost înregistrată cu succes în registrul comun pe Polygon Amoy!`);
      setName('');
      setAddress('');
      setRelationship('');

      setTimeout(() => setSuccessMessage(null), 5000);
    }, 900);
  };

  const filteredFriends = friends.filter(
    (f) =>
      f.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      f.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
      f.relationship.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Section Header */}
      <div className="border-b border-slate-800 pb-5">
        <h2 className="text-2xl font-bold text-white tracking-tight">
          Secțiunea 1: Registrul Distribuit al Persoanelor Dragi
        </h2>
        <p className="mt-1 text-sm text-slate-400">
          Oricare dintre membrii autorizați din grup poate adăuga noi sărbătoriți (adresa lor publică de portofel). Odată înscrisă pe Polygon, decizia este permanentă și vizibilă pentru toate nodurile din rețea.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Form Column */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <UserPlus className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white">Înregistrează o Persoană Nouă</h3>
              <p className="text-xs text-slate-400">Apel smart contract: adaugaPersoanaDraga</p>
            </div>
          </div>

          {successMessage && (
            <div className="mb-4 p-3 rounded-lg bg-emerald-950/70 border border-emerald-500/40 text-emerald-200 text-xs flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
              <span>{successMessage}</span>
            </div>
          )}

          {errorMessage && (
            <div className="mb-4 p-3 rounded-lg bg-rose-950/70 border border-rose-500/40 text-rose-200 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Nume și Prenume / Poreclă *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="ex: Doina Popescu (Mama) sau Vasile"
                required
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-colors"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Adresă Publică Portofel (Polygon / Ethereum) *
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="0x71C5678b8686940e7aDb524eC955aAb7e2E6e579"
                required
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-colors"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Trebuie să fie o adresă publică validă (MetaMask/Phantom).
              </span>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Relație / Rol în Grup
              </label>
              <input
                type="text"
                value={relationship}
                onChange={(e) => setRelationship(e.target.value)}
                placeholder="ex: Familie, Coleg Liceu, Prietenă Copilărie"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-colors"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-2.5 px-4 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:bg-slate-800 disabled:text-slate-500 text-slate-950 text-xs font-bold tracking-wide uppercase shadow-md transition-all flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                    <span>Se semnează tranzacția...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>Salvează în Blockchain</span>
                  </>
                )}
              </button>
            </div>

            <div className="text-[11px] text-slate-400 bg-slate-950/60 p-3 rounded-lg border border-slate-800/80 leading-relaxed">
              💡 <strong>Ce se întâmplă tehnic:</strong> Aplicația trimite o tranzacție către contractul <code>FelicitariPrieteni.sol</code> pe rețeaua Polygon Amoy. MetaMask solicită semnătura cheii private pentru a include adresa în registrul distribuit public.
            </div>
          </form>
        </div>

        {/* Distributed List Column */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-semibold text-white">
                Membri & Sărbătoriți Înregistrați ({friends.length})
              </h3>
              <p className="text-xs text-slate-400">
                Lista ta privată de sărbătoriți și prieteni din rețeaua Polygon Amoy
              </p>
            </div>

            <div className="flex items-center gap-2">
              {friends.length > 0 && (
                <button
                  type="button"
                  onClick={() => setShowClearConfirm(true)}
                  className="px-2.5 py-1.5 rounded-lg border border-rose-500/30 text-rose-300 hover:bg-rose-500/10 text-xs font-medium transition-colors flex items-center gap-1 shrink-0"
                  title="Șterge toți prietenii din listă"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Șterge toți</span>
                </button>
              )}

              {/* Search Bar */}
              <div className="relative w-full sm:w-56">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Caută în listă..."
                  className="w-full pl-9 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>
          </div>

          {/* Friends Table / Cards */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
            <div className="max-h-[520px] overflow-y-auto divide-y divide-slate-800/80">
              {filteredFriends.map((friend) => (
                <div
                  key={friend.id}
                  className="p-4 hover:bg-slate-850/60 transition-colors flex items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center text-white text-xs font-bold uppercase shrink-0">
                      {friend.name.slice(0, 2)}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-sm text-white truncate">
                          {friend.name}
                        </span>
                        {friend.initialMember && (
                          <span className="text-[10px] text-amber-300 font-mono">
                            Membru Fondator
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-slate-400">
                        <span className="font-mono text-[11px] text-slate-400">
                          {shortenAddress(friend.address)}
                        </span>
                        <span>·</span>
                        <span className="text-slate-400 text-xs truncate max-w-[150px]">
                          {friend.relationship}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => onSelectRecipientForGreeting(friend)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 transition-colors"
                    >
                      <Send className="w-3 h-3" />
                      <span>Trimite NFT</span>
                    </button>
                    
                    <a
                      href={`${POLYGON_AMOY_CONFIG.blockExplorerUrl}/address/${friend.address}`}
                      target="_blank"
                      rel="noreferrer"
                      title="Vizualizează adresa pe Polygonscan"
                      className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>

                    <button
                      type="button"
                      onClick={() => setFriendToDelete(friend)}
                      title={`Șterge pe ${friend.name} din listă`}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}

              {friends.length === 0 && (
                <div className="p-12 text-center space-y-3">
                  <div className="w-12 h-12 mx-auto rounded-full bg-slate-800/80 flex items-center justify-center text-slate-500">
                    <UserPlus className="w-6 h-6 text-amber-400" />
                  </div>
                  <h4 className="text-sm font-semibold text-white">Nu ai adăugat încă niciun prieten</h4>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
                    Lista ta este curată! Completează formularul din stânga cu numele și adresa de portofel (0x...) a persoanei dragi pentru a o înregistra în grup.
                  </p>
                </div>
              )}

              {friends.length > 0 && filteredFriends.length === 0 && (
                <div className="p-8 text-center text-slate-500 text-sm">
                  Nu a fost găsit niciun prieten care să corespundă căutării „{searchTerm}”.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Confirmation Modal for Single Friend Deletion */}
      {friendToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-700 p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 flex items-center justify-center">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Confirmare Ștergere</h3>
                <p className="text-xs text-slate-400">Revocare din registrul de persoane dragi</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Ești sigur că vrei să elimini persoana <strong>{friendToDelete.name}</strong> ({shortenAddress(friendToDelete.address)}) din lista grupului?
            </p>

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setFriendToDelete(null)}
                className="px-4 py-2 rounded-lg text-xs font-medium text-slate-300 hover:bg-slate-800 transition-colors"
              >
                Anulează
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteFriend(friendToDelete.id);
                  setFriendToDelete(null);
                }}
                className="px-4 py-2 rounded-lg text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white transition-colors flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Șterge Prietenul</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal for Clear All */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-700 p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 flex items-center justify-center">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Ștergere Completă Listă</h3>
                <p className="text-xs text-slate-400">Toate persoanele vor fi eliminate din listă</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Ești sigur că vrei să ștergi toți cei {friends.length} prieteni din listă? Această acțiune va reseta lista complet.
            </p>

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowClearConfirm(false)}
                className="px-4 py-2 rounded-lg text-xs font-medium text-slate-300 hover:bg-slate-800 transition-colors"
              >
                Anulează
              </button>
              <button
                type="button"
                onClick={() => {
                  onClearAllFriends();
                  setShowClearConfirm(false);
                }}
                className="px-4 py-2 rounded-lg text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white transition-colors flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Confirmă Ștergerea Totală</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
