import React, { useState, useEffect } from 'react';
import { Send, Image as ImageIcon, Sparkles, AlertCircle, CheckCircle2, ShieldCheck, RefreshCw } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Friend, NFTGreeting } from '../types/web3';
import { generatePseudoTxHash, shortenAddress } from '../services/web3Service';
import { FestiveVectorArt, THEME_STYLES } from './NFTCardVisualizer';

interface Props {
  friends: Friend[];
  selectedFriend: Friend | null;
  onSendGreeting: (newGreeting: NFTGreeting) => void;
  onGoToAddFriends?: () => void;
  activeAddress: string;
  activeName: string;
}

export const IPFS_PRESETS = [
  {
    name: 'Aniversare de Aur (Gold)',
    theme: 'gold' as const,
    ipfsUri: 'ipfs://bafybeigdyrzt5sfp7udm7hu76uh7y26nf3efuylqabf3oclgtqy55fbzdi/birthday_gold.json',
    defaultTitle: 'La Mulți Ani Festiv! 🎂✨',
    defaultMsg: 'Să ai o zi minunată și un an plin de realizări mărețe, fericire și zâmbete! Am imortalizat această urare pe blockchain pentru totdeauna.',
  },
  {
    name: 'Magia Iernii & Anul Nou',
    theme: 'winter' as const,
    ipfsUri: 'ipfs://bafybeicgqpvfvsz3j6k3n6l7f8h9m0p1q2r3s4t5u6v7w8x9y0z1a2b3c4/winter_ember.json',
    defaultTitle: 'Sărbători de Poveste & An Nou Fericit! ❄️✨',
    defaultMsg: 'Lumina și căldura sărbătorilor de iarnă să îți umple casa și sufletul! Să ne revedem cu bine și bucurie în anul ce vine.',
  },
  {
    name: 'Constelația Prieteniei (Starlight)',
    theme: 'starlight' as const,
    ipfsUri: 'ipfs://bafybeihkm6f2x9z3q4e7t1w8s5u0r2c4d6f8g0h2j4k6l8m0n2p4q6r8s0/friendship_stars.json',
    defaultTitle: 'Mulțumesc că ești un prieten extraordinar! 🌟💫',
    defaultMsg: 'Prietenia adevărată este rară și de neprețuit. Mă bucur că facem parte din aceeași poveste și că putem împărtăși atâtea amintiri.',
  },
  {
    name: 'Recunoaștere & Triumf (Royal)',
    theme: 'royal' as const,
    ipfsUri: 'ipfs://bafybeidwvgkchb57q6d3rfe2kqlz3e7hfxw7i4b7a2v73d32p7t3q23xba/promotion_crest.json',
    defaultTitle: 'Felicitări din suflet pentru reușită! 🏆🚀',
    defaultMsg: 'Ai demonstrat încă o dată că pasiunea și perseverența duc la rezultate fabuloase! Tot grupul este extrem de mândru de tine.',
  },
  {
    name: 'Armonie & Prosperitate (Emerald)',
    theme: 'emerald' as const,
    ipfsUri: 'ipfs://bafybeifk4v23pxv47h3j6fql2m5n8b7c9w1x0z3a4e5g6h7i8j9k0l1m2n/emerald_harmony.json',
    defaultTitle: 'Gânduri curate de sănătate și belșug! 💎🌿',
    defaultMsg: 'Fie ca fiecare clipă să îți aducă pace interioară, oameni buni aproape și multă energie pozitivă în tot ce întreprinzi.',
  },
];

export const SendGreetingForm: React.FC<Props> = ({
  friends,
  selectedFriend,
  onSendGreeting,
  onGoToAddFriends,
  activeAddress,
  activeName,
}) => {
  const [recipientAddress, setRecipientAddress] = useState<string>('');
  const [title, setTitle] = useState('La Mulți Ani Festiv! 🎂✨');
  const [message, setMessage] = useState(
    'Îți doresc o zi plină de zâmbete și bucurii! Această felicitare rămâne pentru totdeauna în blockchain-ul Polygon ca simbol al prieteniei noastre.'
  );
  const [ipfsUri, setIpfsUri] = useState(IPFS_PRESETS[0].ipfsUri);
  const [theme, setTheme] = useState<'gold' | 'winter' | 'starlight' | 'royal' | 'emerald'>('gold');
  const [isMinting, setIsMinting] = useState(false);
  const [successInfo, setSuccessInfo] = useState<{ tokenId: number; txHash: string; toName: string } | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Sync recipient if passed from outside
  useEffect(() => {
    if (selectedFriend) {
      setRecipientAddress(selectedFriend.address);
    } else if (friends.length > 0 && !recipientAddress) {
      setRecipientAddress(friends[0].address);
    }
  }, [selectedFriend, friends]);

  const handleApplyPreset = (preset: (typeof IPFS_PRESETS)[0]) => {
    setTheme(preset.theme);
    setIpfsUri(preset.ipfsUri);
    setTitle(preset.defaultTitle);
    setMessage(preset.defaultMsg);
  };

  const handleMint = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessInfo(null);

    if (!recipientAddress) {
      setErrorMessage('Alege un sărbătorit destinatar din lista de prieteni!');
      return;
    }

    if (!title.trim() || !message.trim()) {
      setErrorMessage('Titlul și mesajul felicitării nu pot fi goale.');
      return;
    }

    if (!ipfsUri.trim()) {
      setErrorMessage('Link-ul imaginii/metadatelor IPFS este obligatoriu.');
      return;
    }

    const recipient = friends.find(
      (f) => f.address.toLowerCase() === recipientAddress.toLowerCase()
    );
    const toName = recipient ? recipient.name : 'Prieten drag';

    setIsMinting(true);

    // Simulate smart contract mintFelicitare transaction
    setTimeout(() => {
      const generatedTokenId = Math.floor(100 + Math.random() * 900);
      const generatedTx = generatePseudoTxHash();

      const newGreeting: NFTGreeting = {
        id: `nft-${Date.now()}`,
        tokenId: generatedTokenId,
        toAddress: recipientAddress,
        toName: toName,
        fromAddress: activeAddress,
        fromName: activeName,
        title: title.trim(),
        message: message.trim(),
        ipfsUri: ipfsUri.trim(),
        theme: theme,
        timestamp: Date.now(),
        txHash: generatedTx,
        blockNumber: 12500000 + Math.floor(Math.random() * 50000),
      };

      onSendGreeting(newGreeting);
      setIsMinting(false);
      setSuccessInfo({
        tokenId: generatedTokenId,
        txHash: generatedTx,
        toName: toName,
      });

      // Launch celebratory confetti
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.5 },
        colors: ['#fbbf24', '#f59e0b', '#38bdf8', '#a855f7'],
      });
    }, 1200);
  };

  const targetFriend = friends.find(
    (f) => f.address.toLowerCase() === recipientAddress.toLowerCase()
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Section Header */}
      <div className="border-b border-slate-800 pb-5">
        <h2 className="text-2xl font-bold text-white tracking-tight">
          Secțiunea 2: Trimiterea Felicitării Permanente (Mint NFT)
        </h2>
        <p className="mt-1 text-sm text-slate-400">
          Alege sărbătoritul, personalizează mesajul de suflet și atașează imaginea IPFS. Apelul va rula funcția <code>mintFelicitare</code> pe Polygon Amoy, emițând un token ERC-721 permanent în portofelul destinatarului.
        </p>
      </div>

      {successInfo && (
        <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-950/80 to-slate-900 border border-emerald-500/40 text-slate-200 text-sm shadow-xl flex items-start gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="font-semibold text-emerald-300">
              Felicitarea NFT #{successInfo.tokenId} a fost emisă cu succes pe Polygon Amoy!
            </h4>
            <p className="text-xs text-slate-300">
              Sărbătoritul <strong>{successInfo.toName}</strong> a primit noul NFT direct în portofel.
              Hash Tranzacție: <span className="font-mono text-amber-300">{shortenAddress(successInfo.txHash)}</span>
            </p>
          </div>
        </div>
      )}

      {errorMessage && (
        <div className="p-3 rounded-lg bg-rose-950/70 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
          <span>{errorMessage}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Form Column */}
        <form onSubmit={handleMint} className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-7 shadow-xl space-y-5">
          {/* Step 1: Select Recipient */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-300">
                1. Alege Sărbătoritul (Destinatarul NFT-ului) *
              </label>
              {onGoToAddFriends && (
                <button
                  type="button"
                  onClick={onGoToAddFriends}
                  className="text-[11px] text-amber-400 hover:text-amber-300 transition-colors"
                >
                  + Gestionează Prieteni ({friends.length})
                </button>
              )}
            </div>

            {friends.length > 0 ? (
              <select
                value={recipientAddress}
                onChange={(e) => setRecipientAddress(e.target.value)}
                className="w-full px-3 py-2.5 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-amber-400"
              >
                {friends.map((f) => (
                  <option key={f.id} value={f.address}>
                    {f.name} ({f.relationship}) — {shortenAddress(f.address)}
                  </option>
                ))}
              </select>
            ) : (
              <div className="space-y-2">
                <input
                  type="text"
                  value={recipientAddress}
                  onChange={(e) => setRecipientAddress(e.target.value)}
                  placeholder="Introdu adresa publică a sărbătoritului (0x...)"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
                <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-center justify-between">
                  <span>Nu ai încă persoane salvate în listă.</span>
                  {onGoToAddFriends && (
                    <button
                      type="button"
                      onClick={onGoToAddFriends}
                      className="font-bold underline hover:text-white"
                    >
                      Adaugă un prieten
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Quick Festive Preset Selectors */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              2. Alege un Template & Stil de Felicitare:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {IPFS_PRESETS.map((p) => (
                <button
                  key={p.name}
                  type="button"
                  onClick={() => handleApplyPreset(p)}
                  className={`p-2.5 rounded-lg border text-left transition-all text-xs flex flex-col justify-between ${
                    theme === p.theme
                      ? 'border-amber-400 bg-amber-500/10 text-white font-semibold shadow-sm'
                      : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                  }`}
                >
                  <span className="truncate block font-medium">{p.name}</span>
                  <span className="text-[10px] text-slate-400 capitalize mt-1">Stil: {p.theme}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Step 2: IPFS URI input */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-300">
                3. Link Imagine / Metadate IPFS (Pinata) *
              </label>
              <span className="text-[11px] text-amber-400/90 font-mono">Cost stocare: 0 MATIC</span>
            </div>
            <div className="relative">
              <input
                type="text"
                value={ipfsUri}
                onChange={(e) => setIpfsUri(e.target.value)}
                placeholder="ipfs://bafybeig... sau https://gateway.pinata.cloud/ipfs/..."
                required
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
              />
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Imaginile sunt stocate descentralizat pe IPFS. Smart contractul memorează doar hash-ul criptografic (CID-ul) de câteva caractere.
            </p>
          </div>

          {/* Step 3: Title */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              4. Titlu Felicitare / Ocazie *
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="ex: La Mulți Ani, Andrei!"
              required
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
            />
          </div>

          {/* Step 4: Message */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              5. Mesajul Tău Personalizat *
            </label>
            <textarea
              rows={4}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Scrie o urare de suflet..."
              required
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 leading-relaxed"
            />
          </div>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isMinting}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-400 hover:from-amber-300 hover:to-amber-400 disabled:opacity-50 text-slate-950 text-xs font-bold tracking-wide uppercase shadow-lg transition-all flex items-center justify-center gap-2"
            >
              {isMinting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Se procesează tranzacția în nodurile Polygon...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Trimite Felicitarea Permanentă (Mint NFT)</span>
                </>
              )}
            </button>
          </div>
        </form>

        {/* Live Preview Column */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-semibold uppercase tracking-wider text-slate-300">
              Previzualizare NFT în Timp Real
            </span>
            <span className="text-[11px] font-mono text-amber-400">Polygon Amoy Testnet</span>
          </div>

          {/* Visualized Card Preview */}
          <div className={`rounded-2xl border bg-gradient-to-b ${THEME_STYLES[theme].bgGradient} ${THEME_STYLES[theme].borderColor} overflow-hidden shadow-2xl transition-all`}>
            {/* Visual Vector Artwork */}
            <FestiveVectorArt theme={theme} title={title} />

            <div className="p-5">
              <div className="flex items-baseline justify-between text-xs text-slate-400 mb-1.5">
                <span>
                  Pentru: <strong className="text-white">{targetFriend?.name || 'Sărbătorit'}</strong>
                </span>
                <span className="font-mono text-[11px]">Acum</span>
              </div>

              <h3 className="text-lg font-bold text-white tracking-tight mb-2">
                {title || 'Titlu Felicitare'}
              </h3>

              <p className="text-sm text-slate-300 italic font-serif leading-relaxed line-clamp-4 mb-4">
                "{message || 'Mesajul va apărea aici...'}"
              </p>

              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                <span>
                  De la: <strong className="text-white">{activeName}</strong>
                </span>
                <span className="font-mono text-[11px] text-amber-300">
                  {shortenAddress(activeAddress)}
                </span>
              </div>
            </div>
          </div>

          <div className="text-xs text-slate-400 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
            <div className="flex items-center gap-2 text-white font-medium">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Garanția Imutabilității Web3</span>
            </div>
            <p className="text-[11px] leading-relaxed">
              Odată ce tranzacția este confirmată, niciun administrator sau nod nu poate șterge sau altera această felicitare. Ea va dăinui în portofelul sărbătoritului ca dovadă criptografică permanentă.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
