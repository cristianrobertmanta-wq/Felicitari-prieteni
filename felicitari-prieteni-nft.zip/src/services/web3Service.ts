import { ethers } from 'ethers';
import { Friend, NFTGreeting, POLYGON_AMOY_CONFIG } from '../types/web3';
import { CONTRACT_ABI, DEFAULT_CONTRACT_ADDRESS_AMOY } from '../contracts/FelicitariPrieteni';

const STORAGE_KEY_FRIENDS = 'felicitari_nft_friends_v3';
const STORAGE_KEY_GREETINGS = 'felicitari_nft_greetings_v3';
const STORAGE_KEY_CONTRACT = 'felicitari_nft_contract_address';

export const INITIAL_FRIENDS: Friend[] = [];
export const INITIAL_GREETINGS: NFTGreeting[] = [];

// In-Memory & LocalStorage manager
export const getStoredFriends = (): Friend[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_FRIENDS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_FRIENDS, JSON.stringify(INITIAL_FRIENDS));
      return INITIAL_FRIENDS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : INITIAL_FRIENDS;
  } catch {
    return INITIAL_FRIENDS;
  }
};

export const saveStoredFriends = (friends: Friend[]): void => {
  try {
    localStorage.setItem(STORAGE_KEY_FRIENDS, JSON.stringify(friends));
  } catch (e) {
    console.error('Failed to save friends to localStorage', e);
  }
};

export const getStoredGreetings = (): NFTGreeting[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_GREETINGS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_GREETINGS, JSON.stringify(INITIAL_GREETINGS));
      return INITIAL_GREETINGS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : INITIAL_GREETINGS;
  } catch {
    return INITIAL_GREETINGS;
  }
};

export const saveStoredGreetings = (greetings: NFTGreeting[]): void => {
  try {
    localStorage.setItem(STORAGE_KEY_GREETINGS, JSON.stringify(greetings));
  } catch (e) {
    console.error('Failed to save greetings to localStorage', e);
  }
};

export const getContractAddress = (): string => {
  try {
    return localStorage.getItem(STORAGE_KEY_CONTRACT) || DEFAULT_CONTRACT_ADDRESS_AMOY;
  } catch {
    return DEFAULT_CONTRACT_ADDRESS_AMOY;
  }
};

export const setContractAddress = (addr: string): void => {
  try {
    localStorage.setItem(STORAGE_KEY_CONTRACT, addr);
  } catch (e) {
    console.error(e);
  }
};

// Check if window.ethereum exists
export const hasInjectedWeb3 = (): boolean => {
  return typeof window !== 'undefined' && typeof (window as unknown as { ethereum?: unknown }).ethereum !== 'undefined';
};

// Request Accounts from injected wallet
export const requestWalletConnection = async (): Promise<{
  address: string;
  chainId: number;
  balance: string;
}> => {
  const ethereum = (window as unknown as { ethereum: any }).ethereum;
  if (!ethereum) {
    throw new Error('Nu a fost detectat niciun portofel Web3 (MetaMask/Phantom). Folosește modul Simulator sau instalează extensia!');
  }

  const provider = new ethers.BrowserProvider(ethereum);
  const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
  const network = await provider.getNetwork();
  const address = accounts[0];
  const balanceRaw = await provider.getBalance(address);
  const balance = Number(ethers.formatEther(balanceRaw)).toFixed(4);

  return {
    address,
    chainId: Number(network.chainId),
    balance,
  };
};

// Switch network or add Polygon Amoy Testnet to wallet
export const switchToPolygonAmoy = async (): Promise<boolean> => {
  const ethereum = (window as unknown as { ethereum: any }).ethereum;
  if (!ethereum) return false;

  try {
    await ethereum.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: POLYGON_AMOY_CONFIG.chainIdHex }],
    });
    return true;
  } catch (switchError: any) {
    // Error code 4902 indicates that the chain has not been added to MetaMask
    if (switchError.code === 4902 || switchError.data?.originalError?.code === 4902) {
      try {
        await ethereum.request({
          method: 'wallet_addEthereumChain',
          params: [
            {
              chainId: POLYGON_AMOY_CONFIG.chainIdHex,
              chainName: POLYGON_AMOY_CONFIG.name,
              rpcUrls: [POLYGON_AMOY_CONFIG.rpcUrl],
              nativeCurrency: {
                name: 'Polygon Ecosystem Token',
                symbol: POLYGON_AMOY_CONFIG.currencySymbol,
                decimals: 18,
              },
              blockExplorerUrls: [POLYGON_AMOY_CONFIG.blockExplorerUrl],
            },
          ],
        });
        return true;
      } catch (addError) {
        console.error('Eroare la adăugarea rețelei Polygon Amoy:', addError);
        throw addError;
      }
    }
    throw switchError;
  }
};

// Helper: Format wallet address for UI (0x71C...e579)
export const shortenAddress = (address: string): string => {
  if (!address || address.length < 10) return address;
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
};

// Helper: Generate fake deterministic pseudo-tx hash for simulation
export const generatePseudoTxHash = (): string => {
  const chars = '0123456789abcdef';
  let hash = '0x';
  for (let i = 0; i < 64; i++) {
    hash += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return hash;
};
