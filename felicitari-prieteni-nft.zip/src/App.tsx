/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { WallOfMemories } from './components/WallOfMemories';
import { SendGreetingForm } from './components/SendGreetingForm';
import { AddFriendSection } from './components/AddFriendSection';
import { HowBlockchainWorksGuide } from './components/HowBlockchainWorksGuide';
import { SmartContractViewer } from './components/SmartContractViewer';
import { GreetingDetailModal } from './components/GreetingDetailModal';
import { Friend, NFTGreeting, POLYGON_AMOY_CONFIG } from './types/web3';
import {
  getStoredFriends,
  saveStoredFriends,
  getStoredGreetings,
  saveStoredGreetings,
  requestWalletConnection,
  hasInjectedWeb3,
  shortenAddress,
} from './services/web3Service';
import { ExternalLink, ShieldCheck } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'wall' | 'send' | 'friends' | 'guide' | 'contract'>('wall');
  const [friends, setFriends] = useState<Friend[]>(() => getStoredFriends());
  const [greetings, setGreetings] = useState<NFTGreeting[]>(() => getStoredGreetings());
  
  // Wallet / Identity State
  const [isConnected, setIsConnected] = useState<boolean>(true);
  const [isSimulator, setIsSimulator] = useState<boolean>(true);
  const [activeAddress, setActiveAddress] = useState<string>(
    friends[0]?.address || '0x71C5678b8686940e7aDb524eC955aAb7e2E6e579'
  );
  const [activeName, setActiveName] = useState<string>(friends[0]?.name || 'Portofelul Meu');
  const [balance, setBalance] = useState<string>('1.8420');

  // Selected friend for quick send flow
  const [selectedFriendForGreeting, setSelectedFriendForGreeting] = useState<Friend | null>(null);

  // Active greeting detail modal
  const [inspectedGreeting, setInspectedGreeting] = useState<NFTGreeting | null>(null);

  // Real Web3 connection handler (MetaMask)
  const handleConnectRealWallet = async () => {
    try {
      if (!hasInjectedWeb3()) {
        alert(
          'Nu a fost detectată nicio extensie Web3 (MetaMask/Phantom) în acest browser.\n\nAplicația rulează în modul complet funcțional de Simulator cu cei 20 de prieteni din rețea!'
        );
        return;
      }
      const walletData = await requestWalletConnection();
      setActiveAddress(walletData.address);
      const matchedFriend = friends.find(
        (f) => f.address.toLowerCase() === walletData.address.toLowerCase()
      );
      setActiveName(matchedFriend ? matchedFriend.name : 'Portofel Conectat');
      setBalance(walletData.balance);
      setIsSimulator(false);
      setIsConnected(true);
    } catch (err: any) {
      console.warn('Eroare conectare portofel Web3:', err.message);
      alert(`Nu s-a putut conecta portofelul: ${err.message || 'Utilizatorul a refuzat cererea'}`);
    }
  };

  // Switch persona in group simulator
  const handleToggleSimulatorAccount = (friend: Friend) => {
    setActiveAddress(friend.address);
    setActiveName(friend.name);
    setIsSimulator(true);
    setIsConnected(true);
    setBalance('1.8420');
  };

  const handleDisconnect = () => {
    setIsConnected(false);
  };

  // Section 1: Add new friend to distributed list
  const handleAddFriend = (newFriend: Friend) => {
    const updated = [newFriend, ...friends];
    setFriends(updated);
    saveStoredFriends(updated);
  };

  // Section 1: Delete a friend from list
  const handleDeleteFriend = (friendId: string) => {
    const deleted = friends.find((f) => f.id === friendId);
    const updated = friends.filter((f) => f.id !== friendId);
    setFriends(updated);
    saveStoredFriends(updated);
    if (deleted && deleted.address.toLowerCase() === activeAddress.toLowerCase()) {
      setActiveAddress(updated[0]?.address || '0x71C5678b8686940e7aDb524eC955aAb7e2E6e579');
      setActiveName(updated[0]?.name || 'Portofelul Meu');
    }
  };

  // Section 1: Clear all friends from list
  const handleClearAllFriends = () => {
    setFriends([]);
    saveStoredFriends([]);
    setActiveName('Portofelul Meu');
  };

  // Section 2: Send new NFT greeting
  const handleSendGreeting = (newGreeting: NFTGreeting) => {
    const updated = [newGreeting, ...greetings];
    setGreetings(updated);
    saveStoredGreetings(updated);
    setActiveTab('wall');
  };

  // Trigger quick send from friends section
  const handleSelectRecipientForGreeting = (friend: Friend) => {
    setSelectedFriendForGreeting(friend);
    setActiveTab('send');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      {/* Header adhering to Top Bar Contract */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isConnected={isConnected}
        activeAddress={activeAddress}
        activeName={activeName}
        balance={balance}
        isSimulator={isSimulator}
        onConnectRealWallet={handleConnectRealWallet}
        onToggleSimulatorAccount={handleToggleSimulatorAccount}
        onDisconnect={handleDisconnect}
        friends={friends}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation Tab Views */}
        {activeTab === 'wall' && (
          <WallOfMemories
            greetings={greetings}
            activeAddress={activeAddress}
            activeName={activeName}
            onOpenGreeting={(g) => setInspectedGreeting(g)}
            onGoToSendGreeting={() => setActiveTab('send')}
            friends={friends}
            onSelectActiveFriend={handleToggleSimulatorAccount}
          />
        )}

        {activeTab === 'send' && (
          <SendGreetingForm
            friends={friends}
            selectedFriend={selectedFriendForGreeting}
            onSendGreeting={handleSendGreeting}
            onGoToAddFriends={() => setActiveTab('friends')}
            activeAddress={activeAddress}
            activeName={activeName}
          />
        )}

        {activeTab === 'friends' && (
          <AddFriendSection
            friends={friends}
            onAddFriend={handleAddFriend}
            onDeleteFriend={handleDeleteFriend}
            onClearAllFriends={handleClearAllFriends}
            onSelectRecipientForGreeting={handleSelectRecipientForGreeting}
            activeAddress={activeAddress}
            activeName={activeName}
          />
        )}

        {activeTab === 'guide' && <HowBlockchainWorksGuide />}

        {activeTab === 'contract' && <SmartContractViewer />}
      </main>

      {/* Greeting Detail Modal (Full view & cryptographic proofs) */}
      <GreetingDetailModal
        greeting={inspectedGreeting}
        onClose={() => setInspectedGreeting(null)}
      />

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-300">Felicitari Prieteni NFT</span>
            <span>·</span>
            <span>Polygon Amoy Testnet (Chain ID 80002)</span>
            <span>·</span>
            <span>ERC-721 Standard</span>
          </div>

          <div className="flex items-center gap-4">
            <a
              href={POLYGON_AMOY_CONFIG.blockExplorerUrl}
              target="_blank"
              rel="noreferrer"
              className="hover:text-amber-400 transition-colors inline-flex items-center gap-1"
            >
              <span>Polygonscan Amoy</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <span>·</span>
            <span>Grup de 20 de Prieteni & Persoane Dragi</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
